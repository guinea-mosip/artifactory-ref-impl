#!/bin/bash

#installs the Bio-SDK
set -e

echo "Installating Tech5 Bio-SDK.."
mkdir -p /biosdk_rel
export work_dir_env=/biosdk_rel/

cp tech5-sdk-prod-20200711*.jar $work_dir_env
cp gson-*.jar $work_dir_env
cp unirest-java-*.jar $work_dir_env

cp httpcore-nio-*.jar $work_dir_env
cp httpcore-4.4.jar $work_dir_env
cp httpasyncclient-*.jar $work_dir_env

cp config.properties $work_dir_env

export loader_path_env=/biosdk_rel/*

echo "Installating Tech5 Bio-SDK completed."
